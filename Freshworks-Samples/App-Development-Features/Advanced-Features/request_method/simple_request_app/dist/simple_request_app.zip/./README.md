## Simple Request App

This apps makes REST API calls to httpbin.org.

![](screenshots/appView.png)

This app demonstrates the following features

1. Request API - GET, POST, PUT & DELETE
